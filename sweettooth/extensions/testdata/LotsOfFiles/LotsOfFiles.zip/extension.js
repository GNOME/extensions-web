// This is a dumb file.

function init() {
}

var enable, disable;
enable = disable = init;
